import { Injectable, Logger} from '@nestjs/common';
import { PrismaService } from 'prisma/prisma.service';
import { v4 as uuidv4 } from 'uuid';
import * as path from 'path';
import * as fs from 'fs';
import { Response } from 'express';
import * as PDFDocument from 'pdfkit';
import { Stream } from 'stream';
@Injectable()
export class CustomerService {
  private readonly logger = new Logger(this.constructor.name)
  constructor(readonly prismaService: PrismaService) { }


  //get all data
 async cutomerGetData(){
    return await  this.prismaService.customer.findMany({})
 }
 
  //create customer
  async customerData(name: string, email: string, mobile_number: string, address: string) {
    const userId = uuidv4();
     const data =await this.prismaService.customer.create({
      data: {
        user_id: userId,
        Name: name,
        email: email,
        mobile_number: mobile_number,
        address: address
      }
    })
  }

  //update customer
  async CustomerUpdate(userId: string, name: string, email: string, mobile_number: string, address: string) {
    const customer = await this.prismaService.customer.findFirstOrThrow({
      where: {
        user_id: userId
      }
    })
    if (customer) {
      await this.prismaService.customer.update({
        where:{
           user_id:userId
        },
        data: {
          Name: name,
          email: email,
          mobile_number: mobile_number,
          address: address
        },
      })
    }
  }

   //delete customer
  async CustomerDelete(userId:string){
    const customer = await this.prismaService.customer.findFirstOrThrow({
      where: {
        user_id: userId
      }
    })

     if(customer){
       await this.prismaService.customer.delete({
        where:{
          user_id:userId
        }
       })
     }
   }


   
  async downloadPdf(id: string) {
     const data = await this.prismaService.customer.findFirst({
       where:{
        user_id:id
       },
       select:{
          Name :true,
          email:true,
          mobile_number: true,
          address: true
       }
     })
    
  const doc = new PDFDocument();
  const stream = new Stream.PassThrough();
  const chunks: Buffer[] = [];

  doc.on('data', (chunk) => {
      chunks.push(chunk);
  });

  doc.on('end', () => {
      stream.end(Buffer.concat(chunks));
  });

  doc.pipe(stream);

  // Add content to the PDF
  doc.fontSize(25).text('Customer Information', { align: 'center' });
  doc.moveDown();
  doc.fontSize(18).text(`Name: ${data.Name}`);
  doc.fontSize(18).text(`Email: ${data.email}`);
  doc.fontSize(18).text(`Mobile Number: ${data.mobile_number}`);
  doc.fontSize(18).text(`Address: ${data.address}`);

  // Finalize the PDF and end the stream
  doc.end();

  return new Promise((resolve, reject) => {
      const buffers: Buffer[] = [];
      stream.on('data', (buffer) => buffers.push(buffer));
      stream.on('end', () => resolve(Buffer.concat(buffers)));
      stream.on('error', reject);
  });
}
}
